// Links comerciais Ponto Fácil V7.3 — usar somente vendedores oficiais.
// O parâmetro ?v= seleciona o atendimento neste dispositivo e não cria login nem autenticação.
(function (root) {
  'use strict';
  const sellers = Object.freeze({
    luan: Object.freeze({slug:'luan', name:'Luan', whatsapp:'5514997062168'}),
    matheus: Object.freeze({slug:'matheus', name:'Matheus', whatsapp:'5548984585890'}),
    eduardo: Object.freeze({slug:'eduardo', name:'Eduardo', whatsapp:'5548996216774'})
  });
  function get(slug) {
    if (typeof slug !== 'string') return null;
    const key = slug.trim().toLowerCase();
    return Object.prototype.hasOwnProperty.call(sellers, key) ? sellers[key] : null;
  }
  function current(search) {
    const value = typeof search === 'string' ? search : (root.location && root.location.search) || '';
    return get(new URLSearchParams(value).get('v'));
  }
  const api = Object.freeze({get, current});
  root.PF_SELLER_LINKS = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window === 'undefined' ? globalThis : window);
