(() => {
  'use strict';
  let products = Array.isArray(window.PRODUTOS) ? window.PRODUTOS : [];
  const config = window.PONTOFACIL_CONFIG || {};
  const directSeller = window.PF_SELLER_LINKS?.current() || null;
  const byId = id => document.getElementById(id);
  const elements = { grid:byId('productsGrid'), search:byId('search'), sort:byId('sort'), categories:byId('categories'), count:byId('cartCount'), drawer:byId('cartDrawer'), backdrop:byId('cartBackdrop'), cartItems:byId('cartItems'), checkoutArea:byId('checkoutArea'), checkout:byId('checkout'), toast:byId('toast'), configModal:byId('configBackdrop') };
  let selectedCategory = 'Todos';
  let visibleLimit = 24;
  let cart = {};
  let toastTimer;
  let shouldContinueAfterConfig = false;
  let company = null;
  try {
    const saved = JSON.parse(localStorage.getItem('pf_company_v2') || 'null');
    if (saved && typeof saved === 'object' && saved.cnpj && saved.razaoSocial) company = saved;
  } catch (e) {}
  const companyIds = {
    cnpj:'companyCnpj',razaoSocial:'companyName',responsavel:'companyContact',
    telefone:'companyPhone',email:'companyEmail',cep:'companyCep',rua:'companyStreet',
    numero:'companyNumber',bairro:'companyNeighborhood',cidade:'companyCity',tipo:'companySegment',
    uf:'companyState',complemento:'companyComplement'
  };
  try {const loaded = JSON.parse(localStorage.getItem('pf_cart_v1') || '{}');if(loaded && typeof loaded === 'object')cart = loaded;}catch(e){}
  const escapeHTML = s => String(s ?? '').replace(/[&<>"']/g, ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  const formatNumber = n => String(n).replace(/\D/g,'');
  const normalize = s => String(s).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
  const isSafeImage = s => /^(https:\/\/|assets\/|data:image\/(png|jpeg|webp);base64,)/i.test(String(s||''));
  const imageTag = (p,cls='') => p.image&&isSafeImage(p.image)?`<img src="${escapeHTML(p.image)}" class="${cls}" loading="lazy" alt="${escapeHTML(p.name)}">`:`<span class="image-placeholder">Foto indisponível</span>`;
  const priceLabel=p=>p.price==null?'Sob consulta':Number(p.price).toLocaleString('pt-BR',{style:'currency',currency:'BRL'});
  function showToast(message){elements.toast.textContent=message;elements.toast.classList.add('visible');clearTimeout(toastTimer);toastTimer=setTimeout(()=>elements.toast.classList.remove('visible'),2600);}
  function saveCart(){try{localStorage.setItem('pf_cart_v1',JSON.stringify(cart));}catch(e){}updateCartUI();}
  function totalItems(){return Object.values(cart).reduce((t,n)=>t+n,0);}
  function productEntries(){return products.filter(p=>(cart[p.id]||0)>0);}
  function setupCategories(){
    const counts={};for(const p of products)counts[p.category]=(counts[p.category]||0)+1;
    const categories=['Todos',...Object.keys(counts).sort((a,b)=>a.localeCompare(b,'pt-BR'))];
    elements.categories.innerHTML=categories.map(c=>`<button class="category-pill ${c===selectedCategory?'active':''}" type="button" data-category="${escapeHTML(c)}" aria-pressed="${c===selectedCategory}">${escapeHTML(c)} <span class="pill-number">${c==='Todos'?products.length:counts[c]}</span></button>`).join('');
    elements.categories.querySelectorAll('[data-category]').forEach(btn=>btn.addEventListener('click',()=>{selectedCategory=btn.dataset.category;visibleLimit=24;setupCategories();renderProducts();}));
  }
  function renderProducts(){
    const query=normalize(elements.search.value.trim());
    const matches=products.filter(p=>(selectedCategory==='Todos'||p.category===selectedCategory) && (!query||normalize([p.name,p.sku,p.category].join(' ')).includes(query)));
    if(elements.sort.value==='name')matches.sort((a,b)=>a.name.localeCompare(b.name,'pt-BR'));
    if(elements.sort.value==='category')matches.sort((a,b)=>a.category.localeCompare(b.category,'pt-BR')||a.name.localeCompare(b.name,'pt-BR'));
    const visible=matches.slice(0,visibleLimit);
    byId('resultsText').textContent=`Mostrando ${visible.length} de ${matches.length} produto${matches.length===1?'':'s'}`;
    byId('clearFilters').classList.toggle('hidden',selectedCategory==='Todos'&&!query);
    byId('noResults').classList.toggle('hidden',matches.length!==0);
    byId('moreWrap').classList.toggle('hidden',visible.length===matches.length);
    elements.grid.innerHTML=visible.map(p=>{
      const count=cart[p.id]||0;
      return `<article class="product-card"><div class="product-image">${imageTag(p)}<span class="product-badge">${escapeHTML(p.unit)}</span></div><div class="product-body"><span class="product-category">${escapeHTML(p.category)}</span><h3 class="product-name" title="${escapeHTML(p.name)}">${escapeHTML(p.name)}</h3><span class="product-sku">${p.sku?'Cód.: '+escapeHTML(p.sku):'Código não informado'}</span><div class="product-end"><div class="product-price"><small>Preço</small>${priceLabel(p)}</div><button type="button" class="add-btn ${count?'in-cart':''}" data-add="${p.id}" aria-label="Adicionar ${escapeHTML(p.name)} ao pedido"><span class="plus">${count?'✓':'+'}</span>${count?`No carrinho (${count})`:'Adicionar'}</button></div></div></article>`;
    }).join('');
  }
  function addItem(id){const p=products.find(x=>x.id===id);if(!p)return;cart[id]=Math.min(9999,(cart[id]||0)+1);saveCart();renderProducts();showToast(`${p.name} adicionado ao pedido`);}
  function changeQuantity(id,delta){const n=Math.max(0,Math.min(9999,(cart[id]||0)+delta));if(n===0)delete cart[id];else cart[id]=n;saveCart();renderProducts();}
  function updateCartUI(){
    const count=totalItems();elements.count.textContent=count;byId('drawerCount').textContent=`(${count})`;byId('cartSummary').textContent=`${count} ${count===1?'unidade selecionada':'unidades selecionadas'}`;
    elements.checkout.disabled=!count;
    byId('floatingCount').textContent=`${count} ${count===1?'item':'itens'}`;
    byId('floatingCart').hidden=!count||elements.drawer.classList.contains('open');
    elements.checkoutArea.classList.toggle('hidden',!count);
    if(!count){elements.cartItems.innerHTML='<div class="cart-empty"><span class="cart-empty-icon">▤</span><h3>Seu carrinho está vazio</h3><p>Adicione produtos do catálogo para solicitar um orçamento ou fazer seu pedido.</p></div>';return;}
    elements.cartItems.innerHTML=productEntries().map(p=>`<div class="cart-line"><div>${p.image&&isSafeImage(p.image)?`<img class="cart-line-img" alt="" src="${escapeHTML(p.image)}">`:'<span class="image-placeholder">Sem foto</span>'}</div><div><div class="cart-line-name">${escapeHTML(p.name)}</div><div class="cart-line-meta">${escapeHTML(p.unit)} ${p.sku?'· Cód. '+escapeHTML(p.sku):''}</div><div class="qty-control"><button data-qty="-1" data-id="${p.id}" type="button" aria-label="Diminuir quantidade">−</button><span>${cart[p.id]}</span><button data-qty="1" data-id="${p.id}" type="button" aria-label="Aumentar quantidade">+</button></div></div><button type="button" class="remove-btn" data-remove="${p.id}" aria-label="Remover produto">×</button></div>`).join('');
  }

  // Valida CNPJ numérico e alfanumérico (12 posições de base e 2 dígitos verificadores).
  // Números novos também podem conter letras na base, mantendo os verificadores numéricos.
  const cnpjRaw = value => String(value || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  function formatCnpj(value) {
    const s = cnpjRaw(value).slice(0, 14);
    return s.slice(0,2)
      + (s.length > 2 ? '.' + s.slice(2,5) : '')
      + (s.length > 5 ? '.' + s.slice(5,8) : '')
      + (s.length > 8 ? '/' + s.slice(8,12) : '')
      + (s.length > 12 ? '-' + s.slice(12,14) : '');
  }
  function validCnpj(value) {
    const s = cnpjRaw(value);
    if (!/^[0-9A-Z]{12}[0-9]{2}$/.test(s)) return false;
    if (/^(.)\1{13}$/.test(s)) return false;
    const digitValue = character => character.charCodeAt(0) - 48;
    const check = (digits, weights) => {
      const total = [...digits].reduce((sum, letter, index) => sum + digitValue(letter)*weights[index], 0);
      const remainder = total % 11;
      return remainder < 2 ? 0 : 11 - remainder;
    };
    const d1=check(s.slice(0,12),[5,4,3,2,9,8,7,6,5,4,3,2]);
    const d2=check(s.slice(0,12)+String(d1),[6,5,4,3,2,9,8,7,6,5,4,3,2]);
    return s.endsWith(String(d1)+String(d2));
  }
  function formatPhone(value) {
    const d = formatNumber(value).slice(0,11);
    if (d.length <= 2) return d;
    if (d.length <= 6) return '('+d.slice(0,2)+') '+d.slice(2);
    const prefix = d.length > 10 ? 5 : 4;
    return '('+d.slice(0,2)+') '+d.slice(2,2+prefix)+'-'+d.slice(2+prefix);
  }
  function getCompanyField(key) { return byId(companyIds[key]); }
  function companyAddress() {
    if (!company) return '';
    const street = [company.rua, company.numero].filter(Boolean).join(', ');
    return [street, company.complemento, company.bairro, [company.cidade,company.uf].filter(Boolean).join(' / '),company.cep ? 'CEP '+company.cep : ''].filter(Boolean).join(' — ');
  }
  function quoteData(){return {city:byId('quoteCity').value.trim(),neighborhood:byId('quoteNeighborhood').value.trim(),segment:byId('quoteSegment').value.trim()};}
  function quoteAssignment(){
    // Link do vendedor tem preferência absoluta sobre distribuição por região.
    if(directSeller) return {name:directSeller.name,whatsapp:directSeller.whatsapp,rule:null,general:false,direct:true};
    const api=window.PF_BACKEND;
    return window.PF_ROUTING.resolve(quoteData(),api?.getRoutingRules()||[],api?.getSalespeople()||[],waNumber());
  }
  function sellerStatus(){
    const mode=(document.querySelector('[name="mode"]:checked')||{}).value||'cotacao';
    byId('quoteRoutingArea').classList.toggle('hidden',mode!=='cotacao');
    if(mode==='pedido'){
      byId('routingFooterNote').textContent=directSeller
        ?'Seu pedido abrirá no WhatsApp de '+directSeller.name+'. Você confirma o envio.'
        :'O pedido será aberto no WhatsApp da loja, com a mensagem pronta. Você confirma o envio.';
      return;
    }
    const q=quoteData();const a=quoteAssignment();
    const info=byId('assignedSeller');
    if(directSeller){
      info.textContent='Atendimento direto: '+directSeller.name+' · '+formatPhone(directSeller.whatsapp.slice(2));
      byId('sellerRoutingHelp').textContent='Você já está conectado ao seu vendedor. Cidade, bairro e estabelecimento são opcionais.';
    }else if(!q.city||!q.neighborhood||!q.segment){info.textContent='Informe cidade, bairro e tipo de estabelecimento para localizar seu vendedor.';}
    else if(a.general){info.textContent='Atendimento geral — ainda não há vendedor específico para esta combinação.';}
    else{info.textContent='Seu vendedor: '+a.name+' · '+formatPhone(a.whatsapp.slice(2));}
    byId('routingFooterNote').textContent='A cotação abrirá no WhatsApp de '+(a.general?'atendimento geral':a.name)+'. Você confirma o envio.';
  }
  function prefillQuote(){
    if(!company)return;
    const vals={quoteCity:company.cidade,quoteNeighborhood:company.bairro,quoteSegment:company.tipo};
    for(const [key,value] of Object.entries(vals))if(!byId(key).value.trim()&&value)byId(key).value=value;
    sellerStatus();
  }
  function updateCompanyUI() {
    const hasCompany = !!company;
    byId('companyHeaderLabel').textContent = hasCompany ? 'Minha empresa' : 'Cadastro CNPJ';
    byId('openCompanyNav').textContent = hasCompany ? 'Minha empresa' : 'Cadastrar empresa';
    const mode = (document.querySelector('[name="mode"]:checked') || {}).value || 'cotacao';
    byId('orderCompanyArea').classList.toggle('hidden', mode !== 'pedido');
    byId('customerNameField').classList.toggle('hidden', mode === 'pedido');
    byId('customerPhoneField').classList.toggle('hidden', mode === 'pedido');
    const status = byId('companyStatus');
    if (hasCompany) {
      status.innerHTML = '<span class="company-check">✓</span><div><strong>'+escapeHTML(company.razaoSocial)+'</strong><small>CNPJ '+escapeHTML(formatCnpj(company.cnpj))+' · '+escapeHTML(company.responsavel)+'</small></div>';
      byId('openCompanyInCart').textContent = 'Editar dados da empresa →';
      byId('openCompanyInCart').classList.add('edit');
      byId('companyTitle').textContent = 'Dados da sua empresa';
    } else {
      status.innerHTML = '<span class="company-attention">!</span><div><strong>Cadastre sua empresa</strong><small>Informe o CNPJ antes de enviar o pedido.</small></div>';
      byId('openCompanyInCart').textContent = 'Cadastrar empresa com CNPJ →';
      byId('openCompanyInCart').classList.remove('edit');
      byId('companyTitle').textContent = 'Cadastro da sua empresa';
    }
  }
  function openCompany() {
    for (const [key, id] of Object.entries(companyIds)) byId(id).value = company ? (company[key] || '') : '';
    byId('companyConsent').checked = !!company;
    byId('deleteCompany').hidden = !company;
    byId('companyFormError').hidden = true;
    byId('companyBackdrop').hidden = false;
    document.body.style.overflow = 'hidden';
    byId('companyCnpj').focus();
  }
  function closeCompany() {
    byId('companyBackdrop').hidden = true;
    document.body.style.overflow = elements.drawer.classList.contains('open') ? 'hidden' : '';
  }
  function companyFormError(message, target) {
    const box = byId('companyFormError');
    box.textContent = message;
    box.hidden = false;
    if (target) target.focus();
  }
  function saveCompany(event) {
    event.preventDefault();
    const data = {};
    for (const [key,id] of Object.entries(companyIds)) data[key] = byId(id).value.trim();
    data.cnpj = cnpjRaw(data.cnpj);
    data.telefone = formatNumber(data.telefone);
    data.cep = formatNumber(data.cep);
    data.uf = data.uf.toUpperCase();
    if (!validCnpj(data.cnpj)) return companyFormError('CNPJ inválido. Confira os 14 caracteres e os dígitos verificadores.',byId('companyCnpj'));
    if (data.razaoSocial.length < 2) return companyFormError('Informe a razão social da empresa.',byId('companyName'));
    if (data.responsavel.length < 2) return companyFormError('Informe o nome do responsável.',byId('companyContact'));
    if (!/^\d{10,11}$/.test(data.telefone)) return companyFormError('Informe um telefone válido com DDD.',byId('companyPhone'));
    if (data.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) return companyFormError('Confira o endereço de e-mail.',byId('companyEmail'));
    if (data.cep && data.cep.length !== 8) return companyFormError('O CEP precisa ter 8 números.',byId('companyCep'));
    if (data.uf && !/^[A-Z]{2}$/.test(data.uf)) return companyFormError('Informe a UF com duas letras.',byId('companyState'));
    if (!byId('companyConsent').checked) return companyFormError('Confirme que concorda em salvar o cadastro neste dispositivo.',byId('companyConsent'));
    try {
      localStorage.setItem('pf_company_v2',JSON.stringify(data));
    } catch(e) {
      return companyFormError('Não foi possível salvar os dados neste navegador. Verifique se o armazenamento local está liberado.');
    }
    company = data;
    updateCompanyUI();
    prefillQuote();
    closeCompany();
    showToast('Cadastro salvo neste dispositivo. Você já pode fazer seu pedido!');
  }
  function deleteCompany() {
    const confirmed = window.confirm('Deseja apagar os dados da empresa salvos neste dispositivo?');
    if (!confirmed) return;
    try {localStorage.removeItem('pf_company_v2');} catch(e) {}
    company = null;
    updateCompanyUI();
    closeCompany();
    showToast('Cadastro apagado deste dispositivo.');
  }
  function refreshCheckoutMode(){
    const mode=(document.querySelector('[name="mode"]:checked')||{}).value||'cotacao';
    byId('checkoutLabel').textContent=mode==='pedido'?'Enviar pedido pelo WhatsApp':'Enviar cotação pelo WhatsApp';
    updateCompanyUI();sellerStatus();
  }

  function openDrawer(){sellerStatus();elements.drawer.classList.add('open');elements.drawer.setAttribute('aria-hidden','false');elements.backdrop.hidden=false;requestAnimationFrame(()=>elements.backdrop.classList.add('show'));document.body.style.overflow='hidden';byId('floatingCart').hidden=true;byId('closeCart').focus();}
  function closeDrawer(){elements.drawer.classList.remove('open');elements.drawer.setAttribute('aria-hidden','true');elements.backdrop.classList.remove('show');elements.backdrop.hidden=true;document.body.style.overflow='';byId('floatingCart').hidden=totalItems()===0;}
  function waNumber(){const number=formatNumber(config.whatsapp||'');if(number)return number;let local='';try{local=localStorage.getItem('pf_whatsapp_preview')||'';}catch(e){}return formatNumber(local);}
  function validateNumber(value){const n=formatNumber(value);return /^55\d{10,11}$/.test(n)?n:null;}
  function openConfig(){elements.configModal.hidden=false;byId('waNumber').focus();}
  function closeConfig(){elements.configModal.hidden=true;shouldContinueAfterConfig=false;}
  // V7: payload da cotação é criptografado para o vendedor. A senha nunca vai no link.
  const quoteB64 = bytes => {
    const u = new Uint8Array(bytes);
    let s='';for(let i=0;i<u.length;i+=16384)s+=String.fromCharCode(...u.subarray(i,i+16384));
    return btoa(s).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
  };
  const quoteUn64 = s => {
    const r=String(s).replace(/-/g,'+').replace(/_/g,'/');
    const bin=atob(r.padEnd(Math.ceil(r.length/4)*4,'='));
    return Uint8Array.from(bin,c=>c.charCodeAt(0));
  };
  // V8: chave efêmera ECDH P-256 + AES-GCM, formato binário compacto.
  // O PIN nunca é enviado ao cliente, nem fica em texto aberto neste arquivo.
  async function sealedQuoteLink(reference){
    if(!window.crypto?.subtle || !window.PF_V8_PUBLIC_KEY)throw Error('Proteção indisponível. Abra o site por HTTPS.');
    const pk=await crypto.subtle.importKey('spki',quoteUn64(window.PF_V8_PUBLIC_KEY),{name:'ECDH',namedCurve:'P-256'},false,[]);
    const ephemeral=await crypto.subtle.generateKey({name:'ECDH',namedCurve:'P-256'},true,['deriveKey']);
    const aes=await crypto.subtle.deriveKey({name:'ECDH',public:pk},ephemeral.privateKey,{name:'AES-GCM',length:256},false,['encrypt']);
    const iv=crypto.getRandomValues(new Uint8Array(12));
    const ref=String(reference).replace(/^PF-/,'').replace(/[^0-9A-Z]/g,'').slice(0,14);
    const lines=productEntries().map(p=>[p.id,cart[p.id]]);
    if(!lines.length || lines.length>137 || lines.some(([id,qty])=>!Number.isInteger(id)||id<1||id>255||!Number.isInteger(qty)||qty<1||qty>9999))throw Error('Os produtos selecionados são inválidos.');
    // V8, comprimento da referência, bytes ASCII, quantidade de itens, IDs e quantidades.
    const plain=new Uint8Array(3+ref.length+lines.length*3);
    plain[0]=8;plain[1]=ref.length;
    for(let i=0;i<ref.length;i++)plain[2+i]=ref.charCodeAt(i);
    let pos=2+ref.length;plain[pos++]=lines.length;
    for(const [id,qty] of lines){plain[pos++]=id;plain[pos++]=qty>>8;plain[pos++]=qty&255;}
    const encrypted=new Uint8Array(await crypto.subtle.encrypt({name:'AES-GCM',iv,additionalData:new TextEncoder().encode('ponto-facil-v8-quote')},aes,plain));
    const exported=new Uint8Array(await crypto.subtle.exportKey('raw',ephemeral.publicKey));
    const token=new Uint8Array(1+exported.length+iv.length+encrypted.length);
    token[0]=8;token.set(exported,1);token.set(iv,1+exported.length);token.set(encrypted,1+exported.length+iv.length);
    const link=new URL('cotacao.html',window.location.href);
    link.hash='';link.search='';link.searchParams.set('q',quoteB64(token));
    if(directSeller)link.searchParams.set('v',directSeller.slug);
    return link.href;
  }
  async function buildMessage(){
    const mode=(document.querySelector('[name="mode"]:checked')||{}).value||'cotacao';
    const name=byId('customerName').value.trim();const phone=byId('customerPhone').value.trim();const delivery=byId('deliveryType').value;const address=byId('deliveryAddress').value.trim();const notes=byId('cartNotes').value.trim();
    const lines=[mode==='cotacao'?'*PONTO FÁCIL • COTAÇÃO*':'*PONTO FÁCIL • PEDIDO*'];
    if(mode==='cotacao'){
      const referencia='PF-'+Date.now().toString(36).toUpperCase();
      const link=await sealedQuoteLink(referencia);
      const q=quoteData(),a=quoteAssignment();
      lines.push('Ref.: '+referencia,'','*Produtos solicitados:*');
      productEntries().forEach(p=>lines.push(`• ${cart[p.id]} × ${p.name}`));
      lines.push('','*Cliente:* '+name);
      if(phone)lines.push('Telefone: '+phone);
      lines.push('Local: '+[q.neighborhood,q.city].filter(Boolean).join(' / '));
      lines.push('Segmento: '+q.segment);
      lines.push('Vendedor: '+a.name);
      if(delivery==='entrega')lines.push('Entrega: '+(address||'a combinar'));
      else lines.push('Entrega: '+(delivery==='retirada'?'Retirada':'A combinar'));
      if(notes)lines.push('Obs.: '+notes);
      lines.push('','*RESPONDER COTAÇÃO (PIN de 4 dígitos):*',link);
    } else {
      lines.push('','*Produtos:*');
      productEntries().forEach(p=>{lines.push(`• ${cart[p.id]} × ${p.name}`);if(p.price!=null)lines.push('  Preço: '+priceLabel(p));});
      if(company){lines.push('','*Cliente:* '+company.razaoSocial,'CNPJ: '+formatCnpj(company.cnpj),'Contato: '+company.responsavel,'Telefone: '+formatPhone(company.telefone));if(company.email)lines.push('E-mail: '+company.email);}
      else {lines.push('','*Cliente:* '+name);if(phone)lines.push('Telefone: '+phone);}
      lines.push('Entrega: '+(delivery==='entrega'?(address||companyAddress()||'a combinar'):delivery==='retirada'?'Retirada':'A combinar'));
      if(notes)lines.push('Obs.: '+notes);
      if(directSeller)lines.push('Vendedor: '+directSeller.name);
      lines.push('','Por favor, confirme os valores e a disponibilidade.');
    }
    return lines.join('\n');
  }
  async function checkout(){
    if(totalItems()===0)return;
    const mode=(document.querySelector('[name="mode"]:checked')||{}).value||'cotacao';
    if (mode === 'pedido') {
      if (!company) {
        showToast('Cadastre seu CNPJ para enviar o pedido.');
        openCompany();
        return;
      }
    } else {
      const name = byId('customerName');
      if(!name.value.trim()){showToast('Informe seu nome ou empresa para continuar.');name.focus();return;}
    }
    if(mode==='cotacao'){
      const q=quoteData();
      for(const [value,id,message] of (directSeller?[]:[[q.city,'quoteCity','Informe a cidade.'],[q.neighborhood,'quoteNeighborhood','Informe o bairro do estabelecimento.'],[q.segment,'quoteSegment','Informe o tipo de estabelecimento.']])){
        if(!value){showToast(message);byId(id).focus();return;}
      }
    }
    const destination=mode==='cotacao'?quoteAssignment():(directSeller||{whatsapp:waNumber(),general:true});
    const n=destination.whatsapp;if(!validateNumber(n)){shouldContinueAfterConfig=true;openConfig();return;}
    // Abrir a guia durante o clique evita bloqueio de popup após criptografia assíncrona.
    const waTab=window.open('about:blank','_blank');
    if(waTab){waTab.opener=null;try{waTab.document.title='Preparando cotação...';}catch(e){}}
    try{
      const message=await buildMessage();
      const url='https://wa.me/'+n+'?text='+encodeURIComponent(message);
      if(waTab&&!waTab.closed){waTab.location.replace(url)}else{window.location.assign(url)}
      showToast('Mensagem preparada. Confirme o envio no WhatsApp.');
    }catch(err){if(waTab&&!waTab.closed)waTab.close();showToast('Não foi possível proteger a cotação. Tente novamente em HTTPS.');console.error(err)}
  }
  function init(){
    if(directSeller){
      const badge=byId('sellerLandingInfo');
      byId('sellerLandingName').textContent=directSeller.name;
      badge.hidden=false;
      const chat=byId('pfDirectWhatsapp');
      if(chat){
        chat.href='https://wa.me/'+directSeller.whatsapp+'?text='+encodeURIComponent('Olá, '+directSeller.name+'! Vim pelo seu link da Ponto Fácil e gostaria de atendimento.');
        chat.setAttribute('aria-label','Falar com '+directSeller.name+' pelo WhatsApp');
      }
      document.querySelectorAll('#quoteRoutingArea .field > span').forEach(span=>{span.textContent=' (opcional)';span.style.color='#8397a6';});
    }
    byId('currentYear').textContent=new Date().getFullYear();
    byId('totalProducts').textContent=`${products.length} produtos no catálogo`;
    setupCategories();renderProducts();updateCartUI();refreshCheckoutMode();prefillQuote();
    elements.grid.addEventListener('click',e=>{const add=e.target.closest('[data-add]');if(add)addItem(Number(add.dataset.add));});
    elements.cartItems.addEventListener('click',e=>{const qty=e.target.closest('[data-qty]');if(qty)changeQuantity(Number(qty.dataset.id),Number(qty.dataset.qty));const remove=e.target.closest('[data-remove]');if(remove){delete cart[Number(remove.dataset.remove)];saveCart();renderProducts();}});
    elements.search.addEventListener('input',()=>{visibleLimit=24;renderProducts();});elements.sort.addEventListener('change',renderProducts);
    byId('showMore').addEventListener('click',()=>{visibleLimit+=24;renderProducts();});
    const reset=()=>{selectedCategory='Todos';elements.search.value='';visibleLimit=24;setupCategories();renderProducts();};
    byId('clearFilters').addEventListener('click',reset);byId('resetSearch').addEventListener('click',reset);
    ['openCart','bottomCart','floatingCartBtn'].forEach(id=>byId(id).addEventListener('click',openDrawer));
    byId('closeCart').addEventListener('click',closeDrawer);elements.backdrop.addEventListener('click',closeDrawer);document.addEventListener('keydown',e=>{if(e.key==='Escape'){if(!byId('companyBackdrop').hidden)closeCompany();else if(!elements.configModal.hidden)closeConfig();else if(elements.drawer.classList.contains('open'))closeDrawer();}});
    elements.checkout.addEventListener('click',checkout);
    ['quoteCity','quoteNeighborhood','quoteSegment'].forEach(id=>byId(id).addEventListener('input',sellerStatus));
    byId('deliveryType').addEventListener('change',e=>{byId('addressField').hidden=e.target.value!=='entrega';});
    document.querySelectorAll('[name="mode"]').forEach(x=>x.addEventListener('change',refreshCheckoutMode));
    ['openCompanyHeader','openCompanyNav','openCompanyInCart'].forEach(id=>byId(id).addEventListener('click',openCompany));
    byId('closeCompany').addEventListener('click',closeCompany);
    byId('companyBackdrop').addEventListener('click',e=>{if(e.target===byId('companyBackdrop'))closeCompany();});
    byId('companyForm').addEventListener('submit',saveCompany);
    byId('deleteCompany').addEventListener('click',deleteCompany);
    byId('companyCnpj').addEventListener('blur',e=>{e.target.value=formatCnpj(e.target.value);});
    byId('companyPhone').addEventListener('blur',e=>{e.target.value=formatPhone(e.target.value);});
    byId('companyCep').addEventListener('blur',e=>{let c=formatNumber(e.target.value).slice(0,8);e.target.value=c.length>5?c.slice(0,5)+'-'+c.slice(5):c;});
    byId('closeConfig').addEventListener('click',closeConfig);
    byId('saveConfig').addEventListener('click',()=>{const n=validateNumber(byId('waNumber').value);if(!n){showToast('Informe 55 + DDD + número do WhatsApp.');byId('waNumber').focus();return;}
      try{localStorage.setItem('pf_whatsapp_preview',n);}catch(e){}
      const cont=shouldContinueAfterConfig;closeConfig();sellerStatus();showToast('WhatsApp configurado neste navegador.');if(cont)checkout();
    });
  }
  document.addEventListener('pf:catalog-changed',ev=>{
    products=ev.detail.products||[];
    Object.assign(config,ev.detail.settings||{});
    const h=byId('heroTitle'),sub=byId('heroSubtitle');
    if(h && ev.detail.settings?.tagline && h.textContent.trim() !== ev.detail.settings.tagline.trim())h.textContent=ev.detail.settings.tagline;
    if(sub && ev.detail.settings?.subtitle)sub.textContent=ev.detail.settings.subtitle;
    const total=byId('totalProducts');if(total)total.textContent=`${products.length} produtos no catálogo`;
    if(elements.grid){setupCategories();renderProducts();updateCartUI();sellerStatus();}
  });
  if(window.PF_BACKEND){window.PF_BACKEND.loadPublic().catch(e=>{console.error('Não foi possível carregar catálogo online:',e);const total=byId('totalProducts');if(total)total.textContent='Falha ao carregar catálogo online';if(elements.grid)elements.grid.innerHTML='<p>Catálogo temporariamente indisponível. Tente atualizar a página.</p>';});}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
