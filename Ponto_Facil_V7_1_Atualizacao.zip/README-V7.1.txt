PONTO FÁCIL — V7.1 | ATUALIZAÇÃO PARA RENDER

Esta atualização mantém o catálogo e acrescenta proteção por PIN de 4 dígitos
para o vendedor abrir links de orçamento, campos adaptados ao celular
(evitando zoom automático) e mensagens do WhatsApp sem códigos dos produtos.

PUBLICAÇÃO
1. No GitHub, remova o ZIP antigo da raiz do repositório.
2. Envie este ZIP e confirme o commit. Mantenha apenas um arquivo .zip na raiz.
3. Render: Build Command = unzip -oq ./*.zip -d build && mkdir -p public && cp -R build/site/. public/ && rm -f public/admin.html public/admin.js public/admin.css
4. Confira o Deploy LIVE e teste cliente > WhatsApp > PIN > preços > PDF.

SEGURANÇA
NÃO coloque o arquivo da senha privada no GitHub, na Render ou dentro deste ZIP.
O PIN de quatro dígitos NÃO é controle de acesso robusto. A verificação é
realizada no navegador e não possui limitação de tentativas no servidor.
Não use para conteúdo sigiloso nem dependa disso como autenticação individual.
O PDF é salvo manualmente e compartilhado pelo vendedor.
