(() => {
 'use strict';
 const api=window.PF_BACKEND;
 const $=id=>document.getElementById(id);
 let rows=[], editing=null, toastTimeout;
 const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const money=n=>n==null||n===''?'Sob consulta':Number(n).toLocaleString('pt-BR',{style:'currency',currency:'BRL'});
 const normalize=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
 const validImg=s=>/^(https:\/\/|assets\/|data:image\/(png|jpeg|webp);base64,)/i.test(String(s||''));
 function toast(message){$('toast').textContent=message;$('toast').classList.add('visible');clearTimeout(toastTimeout);toastTimeout=setTimeout(()=>$('toast').classList.remove('visible'),3000);}
 function busy(el,flag){el.disabled=flag;}
 function render(){
   rows=api.getProducts({all:true});
   $('statAll').textContent=rows.length;
   $('statActive').textContent=rows.filter(p=>p.active).length;
   $('statPriced').textContent=rows.filter(p=>p.price!=null).length;
   const cats=[...new Set(rows.map(p=>p.category))].filter(Boolean).sort((a,b)=>a.localeCompare(b,'pt-BR'));
   $('statCats').textContent=cats.length;
   const keep=$('categoryFilter').value;
   $('categoryFilter').innerHTML='<option value="">Todas as categorias</option>'+cats.map(c=>`<option value="${esc(c)}">${esc(c)}</option>`).join('');
   if(cats.includes(keep))$('categoryFilter').value=keep;
   $('categoryOptions').innerHTML=cats.map(c=>`<option value="${esc(c)}"></option>`).join('');
   const q=normalize($('productSearch').value.trim());const status=$('statusFilter').value;const cat=$('categoryFilter').value;
   const filtered=rows.filter(p=>(!cat||p.category===cat)&&(!q||normalize([p.name,p.sku,p.category].join(' ')).includes(q))&&(!status||(status==='active'?p.active:!p.active)));
   $('tableCount').textContent=`${filtered.length} resultado(s)`;
   $('productRows').innerHTML=filtered.map(p=>`<tr><td><div class="product-cell">${p.image&&validImg(p.image)?`<img src="${esc(p.image)}" alt="">`:'<span class="product-placeholder">Sem foto</span>'}<div><strong>${esc(p.name)}</strong><small>ID ${p.id} · ${esc(p.unit)}</small></div></div></td><td>${esc(p.sku)||'—'}</td><td>${esc(p.category)}</td><td>${money(p.price)}</td><td><span class="status ${p.active?'active':'hidden'}">${p.active?'Publicado':'Oculto'}</span></td><td><button class="row-btn" data-edit="${p.id}" type="button">Editar →</button></td></tr>`).join('');
   $('emptyProducts').hidden=!!filtered.length;
   $('importPrompt').hidden=!(api.enabled&&rows.length===0);
 }
 function settingsForm(){const s=api.getSettings();$('sWhatsapp').value=s.whatsapp||'';$('sEmpresa').value=s.empresa||'';$('sCidade').value=s.cidade||'';$('sTagline').value=s.tagline||'';$('sSubtitle').value=s.subtitle||'';}
 function openModal(p){
   editing=p||null;$('productForm').reset();$('productError').hidden=true;
   $('modalTitle').textContent=p?'Editar produto':'Novo produto';
   $('pId').value=p?.id||'';$('pName').value=p?.name||'';$('pSku').value=p?.sku||'';
   $('pCategory').value=p?.category||'';$('pUnit').value=p?.unit||'Unidade';
   $('pPrice').value=p?.price==null?'':Number(p.price).toFixed(2).replace('.',',');
   $('pDescription').value=p?.description||'';$('pImage').value=p?.image||'';
   $('pActive').checked=p?.active!==false;$('pFile').value='';photoPreview();
   $('productModal').hidden=false;document.body.style.overflow='hidden';$('pName').focus();
 }
 function closeModal(){$('productModal').hidden=true;document.body.style.overflow='';}
 function photoPreview(){const src=$('pImage').value.trim();$('photoPreview').innerHTML=src&&validImg(src)?`<img src="${esc(src)}" alt="Prévia do produto">`:'Sem foto';}
 function parsePrice(raw){const s=raw.trim();if(!s)return null;const n=Number(s.replace(/\./g,'').replace(',','.'));if(!Number.isFinite(n)||n<0||n>99999999)throw Error('Preço inválido. Use, por exemplo, 19,90.');return Number(n.toFixed(2));}
 async function submitProduct(event){event.preventDefault();const btn=$('saveProduct');busy(btn,true);$('productError').hidden=true;
   try{
     let image=$('pImage').value.trim();const file=$('pFile').files[0];
     if(file){image=await api.uploadPhoto(file);}else if(image&&!validImg(image)){throw Error('Endereço da imagem inválido. Use URL HTTPS ou caminho assets/.');}
     const item={id:Number($('pId').value)||0,name:$('pName').value.trim(),sku:$('pSku').value.trim(),category:$('pCategory').value.trim(),unit:$('pUnit').value,price:parsePrice($('pPrice').value),description:$('pDescription').value.trim(),image,active:$('pActive').checked,sort_order:editing?.sort_order??Math.max(0,...rows.map(r=>r.sort_order||0))+1};
     if(!item.name||!item.category)throw Error('Informe o nome e a categoria do produto.');
     await api.saveProduct(item);closeModal();render();toast('Produto salvo com sucesso.');
   }catch(err){$('productError').textContent=err.message;$('productError').hidden=false;}finally{busy(btn,false);}
 }
 function renderSales(){
   const allS=api.getSalespeople({all:true}),allR=api.getRoutingRules({all:true});
   $('sellerCount').textContent=allS.length+' cadastrado(s)';$('routeCount').textContent=allR.length+' regra(s)';
   $('sellerEmpty').hidden=allS.length!==0;$('routeEmpty').hidden=allR.length!==0;
   $('sellerRows').innerHTML=allS.map(s=>`<tr><td><strong>${esc(s.name)}</strong></td><td>${esc(s.whatsapp)}</td><td><span class="status ${s.active?'active':'hidden'}">${s.active?'Ativo':'Inativo'}</span></td><td><button class="row-btn" type="button" data-edit-seller="${s.id}">Editar →</button></td></tr>`).join('');
   const curr=$('routeSeller').value;
   $('routeSeller').innerHTML='<option value="">Selecione um vendedor</option>'+allS.map(s=>`<option value="${s.id}">${esc(s.name)}${s.active?'':' (inativo)'}</option>`).join('');
   if(allS.some(s=>String(s.id)===curr))$('routeSeller').value=curr;
   $('routeRows').innerHTML=allR.map(r=>{const rep=allS.find(s=>s.id===r.sales_rep_id);return `<tr><td>${esc(rep?.name||'Não encontrado')}</td><td>${esc(r.city||'Qualquer')}</td><td>${esc(r.neighborhood||'Qualquer')}</td><td>${esc(r.segment||'Qualquer')}</td><td>${r.priority}</td><td><span class="status ${r.active&&rep?.active?'active':'hidden'}">${!r.active?'Inativa':!rep?.active?'Vendedor inativo':'Ativa'}</span></td><td><div class="route-actions"><button class="row-btn" type="button" data-edit-route="${r.id}">Editar</button><button class="row-btn" type="button" data-remove-route="${r.id}">Excluir</button></div></td></tr>`;}).join('');
 }
 function resetSellerForm(){$('sellerForm').reset();$('sellerId').value='';$('sellerActive').checked=true;$('sellerSave').textContent='Salvar vendedor';}
 function resetRouteForm(){$('routeForm').reset();$('routeId').value='';$('routeActive').checked=true;$('routePriority').value='0';$('routeSave').textContent='Salvar regra';}
 $('sellerForm').addEventListener('submit',async e=>{
   e.preventDefault();const b=$('sellerSave');busy(b,true);
   try{await api.saveSalesperson({id:Number($('sellerId').value)||0,name:$('sellerName').value,whatsapp:$('sellerWhatsapp').value,active:$('sellerActive').checked});resetSellerForm();renderSales();toast('Vendedor salvo com sucesso.');}
   catch(err){toast('Erro: '+err.message);}finally{busy(b,false);}
 });
 $('routeForm').addEventListener('submit',async e=>{
   e.preventDefault();const b=$('routeSave');busy(b,true);
   try{await api.saveRoutingRule({id:Number($('routeId').value)||0,sales_rep_id:Number($('routeSeller').value),city:$('routeCity').value,neighborhood:$('routeNeighborhood').value,segment:$('routeSegment').value,priority:Number($('routePriority').value),active:$('routeActive').checked});resetRouteForm();renderSales();toast('Regra salva. A simulação já pode ser testada.');}
   catch(err){toast('Erro: '+err.message);}finally{busy(b,false);}
 });
 $('sellerCancel').addEventListener('click',resetSellerForm);$('routeCancel').addEventListener('click',resetRouteForm);
 $('sellerRows').addEventListener('click',e=>{const id=Number(e.target.closest('[data-edit-seller]')?.dataset.editSeller);const r=api.getSalespeople({all:true}).find(x=>x.id===id);if(!r)return;$('sellerId').value=r.id;$('sellerName').value=r.name;$('sellerWhatsapp').value=r.whatsapp;$('sellerActive').checked=r.active;$('sellerSave').textContent='Atualizar vendedor';$('sellerName').focus();});
 $('routeRows').addEventListener('click',async e=>{
   const edit=e.target.closest('[data-edit-route]');const remove=e.target.closest('[data-remove-route]');
   if(edit){const id=Number(edit.dataset.editRoute);const r=api.getRoutingRules({all:true}).find(x=>x.id===id);if(!r)return;$('routeId').value=r.id;$('routeSeller').value=r.sales_rep_id;$('routeCity').value=r.city;$('routeNeighborhood').value=r.neighborhood;$('routeSegment').value=r.segment;$('routePriority').value=r.priority;$('routeActive').checked=r.active;$('routeSave').textContent='Atualizar regra';$('routeSeller').focus();}
   if(remove){const id=Number(remove.dataset.removeRoute);if(!confirm('Excluir esta regra de distribuição?'))return;try{await api.deleteRoutingRule(id);if(Number($('routeId').value)===id)resetRouteForm();renderSales();toast('Regra excluída.');}catch(err){toast('Erro: '+err.message);}}
 });
 $('testRoute').addEventListener('click',()=>{
   const customer={city:$('testCity').value,neighborhood:$('testNeighborhood').value,segment:$('testSegment').value};
   const result=window.PF_ROUTING.resolve(customer,api.getRoutingRules(),api.getSalespeople(),api.getSettings().whatsapp);
   $('testResult').textContent=result.general?'Atendimento geral: '+result.whatsapp+' (nenhuma regra aplicável).':'Vendedor: '+result.name+' · WhatsApp '+result.whatsapp+' · Regra #'+result.rule.id;
 });
 function exportCsv(){
   const cols=['id','name','sku','category','unit','price','active','description','image'];
   const quote=value=>{const s=String(value??'');const safe=/^[=+\-@\t\r]/.test(s)?"'"+s:s;return '"'+safe.replace(/"/g,'""')+'"';};
   const csv='\uFEFF'+[cols.join(';'),...rows.map(p=>cols.map(c=>quote(p[c])).join(';'))].join('\r\n');
   const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));a.download='ponto-facil-catalogo-'+new Date().toISOString().slice(0,10)+'.csv';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);toast('Catálogo exportado.');
 }
 async function init(){
   // Em produção, jamais apresentar o painel de demonstração sem autenticação.
   const isLocal = location.protocol === 'file:' || ['localhost','127.0.0.1'].includes(location.hostname);
   if (!api.enabled && !isLocal) {
     const login = $('loginScreen');
     const form = $('loginForm');
     login.hidden = false;
     form.innerHTML = '<div class="login-mark">PONTO <em>FÁCIL</em></div><span class="eyebrow">ÁREA ADMINISTRATIVA</span><h1>Retaguarda em preparação</h1><p>O catálogo está disponível para pedidos e cotações. A administração será ativada após configurar autenticação e banco de dados online.</p><a class="back-link" href="index.html">← Voltar ao catálogo</a>';
     return;
   }
   $('modeBadge').textContent=api.enabled?'Banco online conectado':'Modo demonstração';$('demoBanner').hidden=api.enabled;$('signout').hidden=!api.enabled;
   if(api.enabled){const ok=await api.restore();if(!ok){$('loginScreen').hidden=false;return;}}
   try{await showDashboard();}catch(err){if(api.enabled){api.signout();$('loginScreen').hidden=false;}toast('Falha ao carregar: '+err.message);}
 }
 async function showDashboard(){await api.loadAdmin();$('loginScreen').hidden=true;$('dashboard').hidden=false;render();settingsForm();renderSales();}
 document.querySelectorAll('.side-tab').forEach(b=>b.addEventListener('click',()=>{
   document.querySelectorAll('.side-tab').forEach(x=>x.classList.toggle('active',x===b));document.querySelectorAll('.page').forEach(x=>x.classList.toggle('active',x.id==='page-'+b.dataset.page));
   $('pageTitle').textContent=({products:'Gestão de produtos',sales:'Vendedores e regiões',settings:'Loja e WhatsApp',help:'Como publicar'})[b.dataset.page];
 }));
 $('loginForm').addEventListener('submit',async event=>{event.preventDefault();const btn=event.currentTarget.querySelector('button');busy(btn,true);$('loginError').hidden=true;try{await api.signin($('loginEmail').value.trim(),$('loginPassword').value);await showDashboard();$('loginPassword').value='';}catch(e){$('loginError').textContent=e.message;$('loginError').hidden=false;}finally{busy(btn,false);}});
 $('signout').addEventListener('click',()=>{api.signout();$('dashboard').hidden=true;$('loginScreen').hidden=false;});
 $('newProduct').addEventListener('click',()=>openModal(null));$('closeModal').addEventListener('click',closeModal);$('cancelModal').addEventListener('click',closeModal);$('productModal').addEventListener('click',event=>{if(event.target===$('productModal'))closeModal();});
 $('pImage').addEventListener('input',photoPreview);$('pFile').addEventListener('change',event=>{const f=event.target.files[0];if(!f)return;if(!f.type.startsWith('image/'))return;const url=URL.createObjectURL(f);$('photoPreview').innerHTML=`<img src="${esc(url)}" alt="Prévia">`;});
 $('productForm').addEventListener('submit',submitProduct);
 $('productRows').addEventListener('click',event=>{const btn=event.target.closest('[data-edit]');if(!btn)return;const p=rows.find(x=>x.id===Number(btn.dataset.edit));if(p)openModal(p);});
 ['productSearch','categoryFilter','statusFilter'].forEach(id=>$(id).addEventListener(id==='productSearch'?'input':'change',render));
 $('exportCsv').addEventListener('click',exportCsv);
 $('settingsForm').addEventListener('submit',async e=>{e.preventDefault();const b=e.currentTarget.querySelector('button[type=submit]');busy(b,true);try{await api.saveSettings({empresa:$('sEmpresa').value,whatsapp:$('sWhatsapp').value,cidade:$('sCidade').value,tagline:$('sTagline').value,subtitle:$('sSubtitle').value});toast('Configurações salvas.');}catch(e){toast('Erro: '+e.message);}finally{busy(b,false);}});
 $('seedProducts').addEventListener('click',async()=>{if(!confirm('Importar os produtos do catálogo inicial? Produtos já cadastrados não serão substituídos.'))return;busy($('seedProducts'),true);try{await api.seedCatalog();render();toast('Catálogo inicial importado!');}catch(err){toast('Erro: '+err.message);}finally{busy($('seedProducts'),false);}});
 document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!$('productModal').hidden)closeModal();});
 init();
})();
