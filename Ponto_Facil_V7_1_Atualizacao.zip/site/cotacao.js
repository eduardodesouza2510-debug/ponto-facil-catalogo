(() => {
 'use strict';
 const $=id=>document.getElementById(id);
 const catalog=Array.isArray(window.PRODUTOS)?window.PRODUTOS:[];
 const money=new Intl.NumberFormat('pt-BR',{style:'currency',currency:'BRL'});
 const fmt=n=>money.format(n||0);
 const escape=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const parse=s=>{let v=String(s??'').trim().replace(/[^0-9.,-]/g,'');if(!v)return NaN;if(v.includes(','))v=v.replace(/\./g,'').replace(',','.');const n=Number(v);return n};
 const quoteUn64 = s => {
    if(typeof s!=='string'||!s||!/^[\w-]+$/.test(s)||s.length>12000)throw Error('Link inválido');
    const base=s.replace(/-/g,'+').replace(/_/g,'/');const raw=atob(base.padEnd(Math.ceil(base.length/4)*4,'='));
    return Uint8Array.from(raw,c=>c.charCodeAt(0));
 };
 const quoteText=x=>new TextDecoder('utf-8',{fatal:true}).decode(x);
 const vendorGate=$('sellerGate'),quoteForm=$('quoteForm'),errorState=$('errorState'),gateError=$('gateError');
 let code='';const items=[];
 async function openQuote(password){
   if(!crypto?.subtle||!window.PF_QUOTE_PRIVATE_WRAPPED)throw Error('Abra o site em HTTPS para usar sua senha.');
   const secret=String(password).trim();
   if(!/^[0-9]{4}$/.test(secret))throw Error('Digite exatamente 4 números do PIN.');
   const p=window.PF_QUOTE_PRIVATE_WRAPPED;
   const base=await crypto.subtle.importKey('raw',new TextEncoder().encode(secret),{name:'PBKDF2'},false,['deriveKey']);
   const key=await crypto.subtle.deriveKey({name:'PBKDF2',salt:quoteUn64(p.salt),iterations:p.iterations,hash:'SHA-256'},base,{name:'AES-GCM',length:256},false,['decrypt']);
   let privBytes;
   try{privBytes=await crypto.subtle.decrypt({name:'AES-GCM',iv:quoteUn64(p.iv),additionalData:new TextEncoder().encode('ponto-facil-v7-private-key')},key,quoteUn64(p.cipher));}
   catch(e){throw Error('PIN incorreto. Confira os quatro números e tente novamente.');}
   const privateKey=await crypto.subtle.importKey('pkcs8',privBytes,{name:'RSA-OAEP',hash:'SHA-256'},false,['decrypt']);
   const hash=new URLSearchParams(location.hash.slice(1)).get('q');
   if(!hash)throw Error('Faltam dados da cotação. Peça ao cliente para gerar um novo link.');
   let msg;
   try{
     msg=JSON.parse(quoteText(quoteUn64(hash)));
     if(msg.v!==7)throw Error('Versão de link incompatível');
     const aesBytes=await crypto.subtle.decrypt({name:'RSA-OAEP'},privateKey,quoteUn64(msg.k));
     const aes=await crypto.subtle.importKey('raw',aesBytes,{name:'AES-GCM'},false,['decrypt']);
     const body=await crypto.subtle.decrypt({name:'AES-GCM',iv:quoteUn64(msg.i),additionalData:new TextEncoder().encode('ponto-facil-v7-quote')},aes,quoteUn64(msg.d));
     const payload=JSON.parse(quoteText(body));
     if(payload.v!==7 || !Array.isArray(payload.items) || payload.items.length<1 || payload.items.length>137)throw Error('Payload inválido');
     const seen=new Set();
     for(const pair of payload.items){
       if(!Array.isArray(pair)||pair.length!==2)continue;
       const [id,qty]=pair;
       const item=catalog.find(x=>x.id===id);
       if(!item||!Number.isInteger(qty)||qty<1||qty>9999||seen.has(id))continue;
       items.push({...item,qty});seen.add(id);
     }
     if(items.length===0)throw Error('Lista de produtos vazia');
     code=String(payload.ref||'').slice(0,42).replace(/[^A-Z0-9-]/gi,'');
   }catch(e){items.length=0;throw Error('Não foi possível abrir este link. Peça ao cliente uma nova cotação.');}
 }
 const qp=new URLSearchParams(location.hash.slice(1)).get('q');
 if(!qp){vendorGate.classList.add('hidden');errorState.classList.remove('hidden');quoteForm.classList.add('hidden');return;}
 $('sellerGateForm').addEventListener('submit',async e=>{
   e.preventDefault();const btn=$('sellerUnlock');
   btn.disabled=true;btn.textContent='Verificando...';gateError.textContent='';
   try{
     await openQuote($('sellerPassword').value);
     $('sellerPassword').value='';
     vendorGate.classList.add('hidden');quoteForm.classList.remove('hidden');
     $('quoteCode').textContent=code||'COTAÇÃO';
     $('itemCount').textContent=items.length+' produto'+(items.length>1?'s':'');
     populateProducts();
     recalc();
   }catch(error){gateError.textContent=error?.message||'Não foi possível abrir cotação.';}
   finally{btn.disabled=false;btn.textContent='Abrir cotação';}
 });
 function populateProducts(){
 $('productGrid').innerHTML=items.map((p,i)=>`<article class="product" id="item${i}">
 <div class="toprow"><div><h3 class="item-name">${escape(p.name)}</h3><div class="sku">${p.sku?'Cód. '+escape(p.sku):'Ponto Fácil'} • ${escape(p.unit)}</div></div><span class="qty">${p.qty} ${escape(p.unit.toLowerCase())}</span></div>
 <div class="fields"><div class="field"><label for="kind${i}">Como vender</label><select id="kind${i}" data-i="${i}"><option value="unit">${escape(p.unit)}</option><option value="box">Caixa</option><option value="bundle">Fardo</option></select></div><div class="field"><label for="price${i}">Preço da apresentação (R$)</label><input id="price${i}" data-i="${i}" class="price" type="text" inputmode="decimal" autocomplete="off" placeholder="0,00"></div><div class="field extra" id="extra${i}"><label for="pack${i}">Unidades de venda por caixa/fardo</label><input id="pack${i}" data-i="${i}" type="number" min="1" max="9999" step="1" inputmode="numeric" value="6"></div></div>
 <div class="bottom"><label><input type="checkbox" id="off${i}" data-i="${i}"> Indisponível</label><b class="line-total" id="line${i}">—</b></div><div class="packnote" id="note${i}">Informe o preço acima</div></article>`).join('');
 }
 function readItem(i){
   const p=items[i],kind=$('kind'+i).value,off=$('off'+i).checked,amount=parse($('price'+i).value);
   const pack=kind==='unit'?1:Number($('pack'+i).value),validPack=Number.isInteger(pack)&&pack>=1&&pack<=9999;
   const qty=validPack?Math.ceil(p.qty/pack):0,validPrice=Number.isFinite(amount)&&amount>=0;
   return {p,kind,off,amount,pack,qty,validPack,validPrice,total:off?0:(validPack&&validPrice?qty*amount:0)};
 }
 function collect(){
  const lines=items.map((_,i)=>readItem(i));
  const sub=lines.reduce((s,x)=>s+x.total,0);
  const rawFreight=parse($('freight').value),rawDiscount=parse($('discount').value);
  const freight=Number.isFinite(rawFreight)?rawFreight:0,discount=Number.isFinite(rawDiscount)?rawDiscount:0;
  return {lines,sub,freight,discount,total:sub+freight-discount,rawFreight,rawDiscount};
 }
 function recalc(){
  items.forEach((_,i)=>{
    const it=readItem(i);
    $('extra'+i).classList.toggle('active',it.kind!=='unit'&&!it.off);
    $('price'+i).disabled=it.off;$('pack'+i).disabled=it.off;$('kind'+i).disabled=it.off;
    $('item'+i).classList.toggle('off',it.off);
    $('line'+i).textContent=it.off?'Sem estoque':it.validPrice&&it.validPack?fmt(it.total):'—';
    $('note'+i).textContent=it.off?'Não entrará no total':it.kind==='unit'?`${it.p.qty} ${it.p.unit.toLowerCase()} solicitadas`:it.validPack?`${it.qty} ${it.kind==='box'?'caixa(s)':'fardo(s)'} com ${it.pack} ${it.p.unit.toLowerCase()} cada, total ${it.qty*it.pack} fornecidas`:'Informe unidades por embalagem';
  });
  const t=collect();$('subtotal').textContent=fmt(t.sub);$('totalFreight').textContent=fmt(t.freight);$('totalDiscount').textContent='− '+fmt(t.discount);$('grandTotal').textContent=fmt(Math.max(0,t.total));return t;
 }
 function validate(){
   const s=recalc(),errors=[];
   for(const x of s.lines){if(!x.off&&!x.validPrice)errors.push('Informe preço para '+x.p.name);if(!x.off&&!x.validPack)errors.push('Corrija unidades por caixa/fardo de '+x.p.name)}
   if(!Number.isFinite(s.rawFreight)||s.rawFreight<0)errors.push('Frete inválido');
   if(!Number.isFinite(s.rawDiscount)||s.rawDiscount<0)errors.push('Desconto inválido');
   if(s.total<0)errors.push('Desconto maior que o valor total');
   if(s.lines.every(x=>x.off))errors.push('Todos os produtos estão indisponíveis');
   if(errors.length){$('validation').textContent=errors.join(' • ');$('validation').hidden=false;$('validation').scrollIntoView({block:'center'});return null;}
   $('validation').hidden=true;return s;
 }
 $('productGrid').addEventListener('input',recalc);$('productGrid').addEventListener('change',recalc);
 ['freight','discount'].forEach(id=>$(id).addEventListener('input',recalc));
 function details(s){return s.lines.map(x=>x.off?`${x.p.name}: sem estoque`:`${x.p.name} — ${x.qty} ${x.kind==='unit'?x.p.unit:x.kind==='box'?'cx':'fardos'} x ${fmt(x.amount)} = ${fmt(x.total)}`)}
 $('printQuote').addEventListener('click',()=>{
   const s=validate();if(!s)return;
   $('pdfCode').textContent='Ref.: '+code;$('pdfClient').textContent=$('clientName').value.trim()||'Não informado';$('pdfSeller').textContent=$('vendorName').value.trim()||'Equipe comercial';
   $('pdfDate').textContent=new Date().toLocaleDateString('pt-BR');$('pdfValid').textContent=$('validDays').value+' dia(s)';$('pdfNotes').textContent=$('sellerNotes').value.trim();
   $('pdfSub').textContent=fmt(s.sub);$('pdfFreight').textContent=fmt(s.freight);$('pdfDiscount').textContent='− '+fmt(s.discount);$('pdfTotal').textContent=fmt(s.total);
   $('pdfRows').innerHTML=s.lines.map(x=>{
     const unit=x.kind==='unit'?x.p.unit:x.kind==='box'?`Caixa c/ ${x.pack} ${x.p.unit}`:`Fardo c/ ${x.pack} ${x.p.unit}`;
     return `<tr><td><b>${escape(x.p.name)}</b><br><small>${escape(x.off?'Indisponível':unit)} • ${escape(x.p.sku||'sem código')}</small></td><td>${x.off?'—':x.qty}</td><td>${x.off?'—':fmt(x.amount)}</td><td>${x.off?'Sem estoque':fmt(x.total)}</td></tr>`;
   }).join('');
   window.print();
 });
 $('sendWhatsApp').addEventListener('click',()=>{
   const s=validate();if(!s)return;
   const phone=$('clientPhone').value.replace(/\D/g,'');
   let n=phone.length===10||phone.length===11?'55'+phone:phone;
   if(n&&!/^55\d{10,11}$/.test(n)){alert('Confira o número do WhatsApp do cliente com DDD ou deixe o campo vazio.');$('clientPhone').focus();return;}
   const text=['*PONTO FÁCIL — ORÇAMENTO*','Ref.: '+code,'Cliente: '+($('clientName').value.trim()||'Não informado'),''].concat(details(s)).concat(['','Subtotal: '+fmt(s.sub),'Frete: '+fmt(s.freight),'Desconto: '+fmt(s.discount),'*TOTAL: '+fmt(s.total)+'*','Validade: '+$('validDays').value+' dia(s)','Valores sujeitos a confirmação comercial.','O PDF deve ser salvo e anexado manualmente pelo vendedor.']).join('\n');
   const url='https://wa.me/'+n+'?text='+encodeURIComponent(text);
   const win=window.open(url,'_blank');if(win)win.opener=null;else window.location.assign(url);
 });
})();