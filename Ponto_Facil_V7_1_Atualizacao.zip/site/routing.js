// Regra pública e determinística de encaminhamento de cotações.
// Bairro + tipo prevalece sobre bairro; bairro prevalece sobre tipo.
// Cidade torna uma regra equivalente mais específica. Prioridade desempata.
(function(root){
  'use strict';
  const clean = v => String(v || '').normalize('NFD').replace(/[\u0300-\u036f]/g,'').trim().replace(/\s+/g,' ').toLocaleLowerCase('pt-BR');
  const phone = v => String(v || '').replace(/\D/g,'');
  function resolve(customer, rules, sellers, generalPhone){
    const fallback = {name:'Atendimento geral', whatsapp:phone(generalPhone), rule:null, general:true};
    if(!Array.isArray(rules)||!Array.isArray(sellers))return fallback;
    const city=clean(customer?.city), neighborhood=clean(customer?.neighborhood), segment=clean(customer?.segment);
    const candidates=[];
    for(const r of rules){
      if(r.active===false)continue;
      const b=clean(r.neighborhood),t=clean(r.segment),c=clean(r.city);
      if(!b&&!t&&!c)continue; // regra vazia nunca pode desviar todas as cotações
      if(b&&b!==neighborhood || t&&t!==segment || c&&c!==city)continue;
      const seller=sellers.find(s=>Number(s.id)===Number(r.sales_rep_id));
      if(!seller||seller.active===false||!/^55\d{10,11}$/.test(phone(seller.whatsapp)))continue;
      const specificity=(b?100:0)+(t?10:0)+(c?1:0);
      candidates.push({seller,rule:r,specificity,priority:Number(r.priority)||0});
    }
    candidates.sort((a,b)=>b.specificity-a.specificity||b.priority-a.priority||Number(a.rule.id)-Number(b.rule.id));
    const best=candidates[0];
    return best?{name:best.seller.name,whatsapp:phone(best.seller.whatsapp),rule:best.rule,general:false}:fallback;
  }
  const api={resolve,normalize:clean};
  if(typeof module!=='undefined' && module.exports)module.exports=api;
  root.PF_ROUTING=api;
})(typeof window==='undefined'?globalThis:window);
