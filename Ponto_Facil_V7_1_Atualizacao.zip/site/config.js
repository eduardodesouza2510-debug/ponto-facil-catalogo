// CONFIGURAÇÃO PONTO FÁCIL — V2
// Os pedidos e cotações abrem o WhatsApp da loja com uma mensagem preenchida.
// O cliente confirma o envio no WhatsApp (não há disparo automático de mensagens).
window.PONTOFACIL_CONFIG = {
  whatsapp: '5548996216774',
  empresa: 'Ponto Fácil',
  cidade: 'Florianópolis - SC',
  atualizadoEm: '07/10/2026'
};
