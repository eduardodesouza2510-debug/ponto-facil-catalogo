// Retaguarda V3: preencher SOMENTE URL e chave publicável (anon) do Supabase.
// Nunca coloque a service_role ou senha de banco neste arquivo.
// Enquanto estiver vazio, o site funciona em DEMONSTRAÇÃO local (neste navegador).
window.PONTOFACIL_BACKEND = {
  url: '',       // Ex.: https://projeto.supabase.co
  anonKey: ''    // Chave publicável/anon do projeto
};
