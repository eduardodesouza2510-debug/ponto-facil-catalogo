(() => {
 'use strict';
 const $=id=>document.getElementById(id);
 const catalog=Array.isArray(window.PRODUTOS)?window.PRODUTOS:[];
 const money=new Intl.NumberFormat('pt-BR',{style:'currency',currency:'BRL'});
 const fmt=n=>money.format(n||0);
 const escape=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const parse=s=>{let v=String(s??'').trim().replace(/[^0-9.,-]/g,'');if(!v)return NaN;if(v.includes(','))v=v.replace(/\./g,'').replace(',','.');const n=Number(v);return n};
 const params=new URLSearchParams(location.search);
 const code=(params.get('ref')||'SEM REFERÊNCIA').slice(0,42).replace(/[^A-Z0-9-]/gi,'');
 const list=(params.get('itens')||'').slice(0,2200);
 const items=[];
 const seen=new Set();
 for(const part of list.split(',').slice(0,137)) {
   const m=/^(\d{1,4})\.(\d{1,4})$/.exec(part);
   if(!m)continue;
   const id=Number(m[1]),qty=Number(m[2]);
   const p=catalog.find(x=>x.id===id);
   if(!p||qty<1||qty>9999||seen.has(id))continue;
   items.push({...p,qty});seen.add(id);
 }
 if(!items.length){$('quoteForm').classList.add('hidden');$('errorState').classList.remove('hidden');return;}
 $('quoteCode').textContent=code||'COTAÇÃO';$('itemCount').textContent=items.length+' produto'+(items.length>1?'s':'');
 $('productGrid').innerHTML=items.map((p,i)=>`<article class="product" id="item${i}">
 <div class="toprow"><div><h3 class="item-name">${escape(p.name)}</h3><div class="sku">${p.sku?'Cód. '+escape(p.sku):'Ponto Fácil'} • ${escape(p.unit)}</div></div><span class="qty">${p.qty} ${escape(p.unit.toLowerCase())}</span></div>
 <div class="fields"><div class="field"><label for="kind${i}">Como vender</label><select id="kind${i}" data-i="${i}"><option value="unit">${escape(p.unit)}</option><option value="box">Caixa</option><option value="bundle">Fardo</option></select></div><div class="field"><label for="price${i}">Preço da apresentação (R$)</label><input id="price${i}" data-i="${i}" class="price" type="text" inputmode="decimal" autocomplete="off" placeholder="0,00"></div><div class="field extra" id="extra${i}"><label for="pack${i}">Unidades de venda por caixa/fardo</label><input id="pack${i}" data-i="${i}" type="number" min="1" max="9999" step="1" inputmode="numeric" value="6"></div></div>
 <div class="bottom"><label><input type="checkbox" id="off${i}" data-i="${i}"> Indisponível</label><b class="line-total" id="line${i}">—</b></div><div class="packnote" id="note${i}">Informe o preço acima</div></article>`).join('');
 function readItem(i){
   const p=items[i],kind=$('kind'+i).value,off=$('off'+i).checked,amount=parse($('price'+i).value);
   const pack=kind==='unit'?1:Number($('pack'+i).value),validPack=Number.isInteger(pack)&&pack>=1&&pack<=9999;
   const qty=validPack?Math.ceil(p.qty/pack):0,validPrice=Number.isFinite(amount)&&amount>=0;
   return {p,kind,off,amount,pack,qty,validPack,validPrice,total:off?0:(validPack&&validPrice?qty*amount:0)};
 }
 function collect(){
  const lines=items.map((_,i)=>readItem(i));
  const sub=lines.reduce((s,x)=>s+x.total,0);
  const rawFreight=parse($('freight').value),rawDiscount=parse($('discount').value);
  const freight=Number.isFinite(rawFreight)?rawFreight:0,discount=Number.isFinite(rawDiscount)?rawDiscount:0;
  return {lines,sub,freight,discount,total:sub+freight-discount,rawFreight,rawDiscount};
 }
 function recalc(){
  items.forEach((_,i)=>{
    const it=readItem(i);
    $('extra'+i).classList.toggle('active',it.kind!=='unit'&&!it.off);
    $('price'+i).disabled=it.off;$('pack'+i).disabled=it.off;$('kind'+i).disabled=it.off;
    $('item'+i).classList.toggle('off',it.off);
    $('line'+i).textContent=it.off?'Sem estoque':it.validPrice&&it.validPack?fmt(it.total):'—';
    $('note'+i).textContent=it.off?'Não entrará no total':it.kind==='unit'?`${it.p.qty} ${it.p.unit.toLowerCase()} solicitadas`:it.validPack?`${it.qty} ${it.kind==='box'?'caixa(s)':'fardo(s)'} com ${it.pack} ${it.p.unit.toLowerCase()} cada, total ${it.qty*it.pack} fornecidas`:'Informe unidades por embalagem';
  });
  const t=collect();$('subtotal').textContent=fmt(t.sub);$('totalFreight').textContent=fmt(t.freight);$('totalDiscount').textContent='− '+fmt(t.discount);$('grandTotal').textContent=fmt(Math.max(0,t.total));return t;
 }
 function validate(){
   const s=recalc(),errors=[];
   for(const x of s.lines){if(!x.off&&!x.validPrice)errors.push('Informe preço para '+x.p.name);if(!x.off&&!x.validPack)errors.push('Corrija unidades por caixa/fardo de '+x.p.name)}
   if(!Number.isFinite(s.rawFreight)||s.rawFreight<0)errors.push('Frete inválido');
   if(!Number.isFinite(s.rawDiscount)||s.rawDiscount<0)errors.push('Desconto inválido');
   if(s.total<0)errors.push('Desconto maior que o valor total');
   if(s.lines.every(x=>x.off))errors.push('Todos os produtos estão indisponíveis');
   if(errors.length){$('validation').textContent=errors.join(' • ');$('validation').hidden=false;$('validation').scrollIntoView({block:'center'});return null;}
   $('validation').hidden=true;return s;
 }
 $('productGrid').addEventListener('input',recalc);$('productGrid').addEventListener('change',recalc);
 ['freight','discount'].forEach(id=>$(id).addEventListener('input',recalc));
 function details(s){return s.lines.map(x=>x.off?`${x.p.name}: sem estoque`:`${x.p.name} — ${x.qty} ${x.kind==='unit'?x.p.unit:x.kind==='box'?'cx':'fardos'} x ${fmt(x.amount)} = ${fmt(x.total)}`)}
 $('printQuote').addEventListener('click',()=>{
   const s=validate();if(!s)return;
   $('pdfCode').textContent='Ref.: '+code;$('pdfClient').textContent=$('clientName').value.trim()||'Não informado';$('pdfSeller').textContent=$('vendorName').value.trim()||'Equipe comercial';
   $('pdfDate').textContent=new Date().toLocaleDateString('pt-BR');$('pdfValid').textContent=$('validDays').value+' dia(s)';$('pdfNotes').textContent=$('sellerNotes').value.trim();
   $('pdfSub').textContent=fmt(s.sub);$('pdfFreight').textContent=fmt(s.freight);$('pdfDiscount').textContent='− '+fmt(s.discount);$('pdfTotal').textContent=fmt(s.total);
   $('pdfRows').innerHTML=s.lines.map(x=>{
     const unit=x.kind==='unit'?x.p.unit:x.kind==='box'?`Caixa c/ ${x.pack} ${x.p.unit}`:`Fardo c/ ${x.pack} ${x.p.unit}`;
     return `<tr><td><b>${escape(x.p.name)}</b><br><small>${escape(x.off?'Indisponível':unit)} • ${escape(x.p.sku||'sem código')}</small></td><td>${x.off?'—':x.qty}</td><td>${x.off?'—':fmt(x.amount)}</td><td>${x.off?'Sem estoque':fmt(x.total)}</td></tr>`;
   }).join('');
   window.print();
 });
 $('sendWhatsApp').addEventListener('click',()=>{
   const s=validate();if(!s)return;
   const phone=$('clientPhone').value.replace(/\D/g,'');
   let n=phone.length===10||phone.length===11?'55'+phone:phone;
   if(n&&!/^55\d{10,11}$/.test(n)){alert('Confira o número do WhatsApp do cliente com DDD ou deixe o campo vazio.');$('clientPhone').focus();return;}
   const text=['*PONTO FÁCIL — ORÇAMENTO*','Ref.: '+code,'Cliente: '+($('clientName').value.trim()||'Não informado'),''].concat(details(s)).concat(['','Subtotal: '+fmt(s.sub),'Frete: '+fmt(s.freight),'Desconto: '+fmt(s.discount),'*TOTAL: '+fmt(s.total)+'*','Validade: '+$('validDays').value+' dia(s)','Valores sujeitos a confirmação comercial.','O PDF deve ser salvo e anexado manualmente pelo vendedor.']).join('\n');
   const url='https://wa.me/'+n+'?text='+encodeURIComponent(text);
   const win=window.open(url,'_blank');if(win)win.opener=null;else window.location.assign(url);
 });
 recalc();
})();