PONTO FÁCIL — PRONTO PARA PUBLICAÇÃO NA RENDER (SITE V4)

O QUE TEM
- site/index.html — catálogo e WhatsApp geral (48) 99621-6774
- site/admin.html — bloqueado na internet até conectar Supabase com autenticação
- site/assets/ — fotos dos produtos
- render.yaml — configuração de site estático para Render (plano de site estático)

IMPORTANTE
O SITE AINDA NÃO FOI PUBLICADO. NÃO HÁ ENDEREÇO ONLINE ATIVO.
A versão pública apresenta os produtos do catálogo inicial e aceita cotações e pedidos via WhatsApp; usuário confirma a mensagem no aplicativo.
O CNPJ é guardado apenas no navegador do próprio cliente. As regras de vendedores ainda não serão compartilhadas até configurar Supabase. Sem essas regras, a cotação abre o WhatsApp geral da loja.
Não deixe ninguém usar a retaguarda para gestão real antes de configurar autenticação, armazenamento central e permissões.

PUBLICAÇÃO COM RENDER + GITHUB
1. Entre em https://github.com/new com sua conta GitHub.
2. Crie um repositório, por exemplo: ponto-facil-catalogo.
3. Faça upload de TODOS os itens desta pasta, incluindo a pasta site/ e o arquivo render.yaml, preservando estrutura.
4. Na Render, escolha New > Static Site, conecte o repositório.
5. Defina o Build Command como: echo Publicando
6. Defina o Publish Directory como: site
7. Confirme criação e aguarde o status Live. A Render informa o URL real onrender.com.
8. TESTE de ponta a ponta catálogo/carrinho/cotação/WhatsApp antes de distribuir o endereço.

CONFIGURAÇÃO FUTURA DA RETAGUARDA
Ao conectar banco Supabase corretamente, ajuste site/backend-config.js com URL e chave pública (anon/publishable), nunca service_role.
Use os arquivos SQL do pacote V4 original. Exija usuário de administrador autorizado, políticas RLS e testes de acesso; isso fará edições, preços e regras de vendedores serem compartilhados online.

OBSERVAÇÕES
- Este arquivo ZIP serve para o deploy. Ele não cria repositório nem publica sozinho.
- Nome na Render pode estar ocupado; somente a URL gerada pela Render será válida.
- Não existem números de vendedores configurados: a loja usa o geral por enquanto.

DOMÍNIO PERSONALIZADO: pontofacilmateriais.com.br
- Os metadados do site, robots.txt e sitemap.xml já usam o domínio informado.
- Primeiro publique o site e aguarde o status Live na Render.
- Depois, no serviço da Render, use Settings > Custom Domains para adicionar:
  pontofacilmateriais.com.br e www.pontofacilmateriais.com.br
- No provedor que administra o DNS, crie/ajuste somente os registros solicitados
  pela Render para esses nomes. Os destinos variam conforme o serviço;
  confira os valores reais no painel antes de editar.
- Não apague MX, SPF, DKIM, DMARC nem outros registros existentes de e-mail.
- Valide o certificado HTTPS e os dois endereços antes de divulgar.
- Não foi realizada nenhuma publicação ou alteração de DNS por este pacote.
