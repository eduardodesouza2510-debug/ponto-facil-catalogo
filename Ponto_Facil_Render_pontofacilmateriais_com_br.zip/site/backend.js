(() => {
 'use strict';
 const cfg = window.PONTOFACIL_BACKEND || {};
 const initial = Array.isArray(window.PRODUTOS) ? window.PRODUTOS : [];
 const validUrl = /^https:\/\/[A-Za-z0-9.-]+\.supabase\.co\/?$/.test((cfg.url || '').trim());
 const enabled = validUrl && !!String(cfg.anonKey || '').trim();
 const base = String(cfg.url || '').replace(/\/$/, '');
 const productKey = 'pf_admin_demo_products_v3';
 const settingsKey = 'pf_admin_demo_settings_v3';
 const sessionKey = 'pf_admin_session_v3';
 const sellersKey='pf_admin_demo_sellers_v4';
 const routesKey='pf_admin_demo_routes_v4';
 const defaults = {whatsapp:'5548996216774',empresa:'Ponto Fácil',cidade:'Florianópolis - SC',tagline:'Tudo o que você precisa. Num só lugar.',subtitle:'Produtos de limpeza, descartáveis, embalagens e muito mais. Escolha os itens, monte sua lista e receba atendimento pelo WhatsApp.'};
 let products = initial.map(x => ({...x, price:null, description:'', active:true, sort_order:x.id}));
 let settings = {...defaults};
 let session = null;
 let sellers=[]; let routes=[];
 const readLocal = (key, fallback) => {try{const v=JSON.parse(localStorage.getItem(key));return v ?? fallback;}catch(e){return fallback;}};
 const writeLocal = (key,val) => {localStorage.setItem(key, JSON.stringify(val));};
 const normProduct = p => ({id:Number(p.id),name:String(p.name || ''),sku:String(p.sku || ''),category:String(p.category || 'Outros'),unit:String(p.unit || 'Unidade'),description:String(p.description || ''),image:String(p.image ?? p.image_url ?? ''),price:p.price === '' || p.price == null ? null : Number(p.price),active:p.active !== false,sort_order:Number(p.sort_order ?? p.id)});
 const fromDb = p => normProduct({...p,image:p.image_url || ''});
 const toDb = p => ({name:p.name,sku:p.sku,category:p.category,unit:p.unit,description:p.description || '',image_url:p.image || '',price:p.price == null ? null : p.price,active:p.active,sort_order:p.sort_order});
 const published = () => products.filter(p=>p.active);
 function emit(){window.PF_PUBLIC_SALESPEOPLE=sellers.filter(s=>s.active);window.PF_PUBLIC_ROUTES=routes.filter(r=>r.active);window.PRODUTOS = published();Object.assign(window.PONTOFACIL_CONFIG || (window.PONTOFACIL_CONFIG = {}),settings);document.dispatchEvent(new CustomEvent('pf:catalog-changed',{detail:{products:window.PRODUTOS,settings}}));}
 function useLocal(){products=readLocal(productKey,initial).map(normProduct);settings={...defaults,...readLocal(settingsKey,{})};sellers=readLocal(sellersKey,[]).map(normSeller);routes=readLocal(routesKey,[]).map(normRule);emit();}
 const normSeller=x=>({id:Number(x.id)||0,name:String(x.name||'').trim(),whatsapp:String(x.whatsapp||'').replace(/\D/g,''),active:x.active!==false});
 const normRule=x=>({id:Number(x.id)||0,sales_rep_id:Number(x.sales_rep_id)||0,city:String(x.city||'').trim(),neighborhood:String(x.neighborhood||'').trim(),segment:String(x.segment||'').trim(),priority:Number(x.priority)||0,active:x.active!==false});
 const getSalespeople=({all=false}={})=>(all?sellers:sellers.filter(s=>s.active)).map(s=>({...s}));
 const getRoutingRules=({all=false}={})=>(all?routes:routes.filter(r=>r.active)).map(r=>({...r}));
 function getSettings(){return {...settings};}
 function getProducts({all=false}={}){return (all?products:published()).map(x=>({...x}));}
 async function loadRouting(admin){
   const auth=admin===true;
   const [a,b]=await Promise.all([
     request('/rest/v1/sales_reps?select=*&order=name.asc',{auth}),
     request('/rest/v1/routing_rules?select=*&order=priority.desc,id.asc',{auth})
   ]);
   sellers=a.map(normSeller);routes=b.map(normRule);
 }
 function headers({auth=true,extra={}}={}){return {'apikey':cfg.anonKey,'Authorization':'Bearer '+(auth && session?.access_token ? session.access_token : cfg.anonKey),...extra};}
 async function request(path, opts={}){
   const res = await fetch(base+path,{...opts,headers:headers({auth:opts.auth !== false,extra:opts.headers || {}})});
   let body;const content=await res.text();try{body=content ? JSON.parse(content):null;}catch(e){body=content;}
   if(!res.ok)throw Error(body?.message||body?.msg||body?.error_description||body?.error||`Erro HTTP ${res.status}`);
   return body;
 }
 async function loadPublic(){
   if(!enabled){useLocal();return;}
   const [rows,sc] = await Promise.all([
     request('/rest/v1/catalog_products?select=*&active=eq.true&order=sort_order.asc,id.asc',{auth:false}),
     request('/rest/v1/site_settings?select=*&id=eq.1',{auth:false})
   ]);
   products=rows.map(fromDb);settings={...defaults,...(sc?.[0] || {})};
   try{await loadRouting(false);}catch(error){console.warn('Roteamento indisponível: execute a migração V4.',error);sellers=[];routes=[];}
   emit();
 }
 async function loadAdmin(){
   if(!enabled){useLocal();return getProducts({all:true});}
   if(!session?.access_token)throw Error('Faça login para continuar.');
   const rows=await request('/rest/v1/catalog_products?select=*&order=sort_order.asc,id.asc');
   products=rows.map(fromDb);
   const sc=await request('/rest/v1/site_settings?select=*&id=eq.1');
   settings={...defaults,...(sc?.[0] || {})};
   try{await loadRouting(true);}catch(error){console.warn('Migração da retaguarda V4 pendente:',error);sellers=[];routes=[];}
   emit();return getProducts({all:true});
 }
 async function signin(email,password){
   if(!enabled)throw Error('Configure o Supabase para ativar o login online.');
   const body = await request('/auth/v1/token?grant_type=password',{method:'POST',auth:false,headers:{'Content-Type':'application/json'},body:JSON.stringify({email,password})});
   session=body;sessionStorage.setItem(sessionKey,JSON.stringify(body));
   try{
     const userId=body.user?.id;
     const rows=await request('/rest/v1/admin_users?select=user_id&user_id=eq.'+encodeURIComponent(userId));
     if(!rows.length)throw Error('Sua conta não tem autorização de administrador.');
   }catch(e){session=null;sessionStorage.removeItem(sessionKey);throw e;}
   return body.user;
 }
 async function restore(){
   if(!enabled)return true;
   session=readSession();if(!session)return false;
   if(session.expires_at && Date.now()/1000>session.expires_at-45){
     try{await refresh();}catch(e){session=null;sessionStorage.removeItem(sessionKey);return false;}
   }
   try{
     const user=await request('/auth/v1/user');
     const rows=await request('/rest/v1/admin_users?select=user_id&user_id=eq.'+encodeURIComponent(user.id));
     if(rows.length)return true;
   }catch(e){}
   session=null;sessionStorage.removeItem(sessionKey);return false;
 }
 function readSession(){try{return JSON.parse(sessionStorage.getItem(sessionKey)||'null');}catch(e){return null;}}
 async function refresh(){
   if(!session?.refresh_token)throw Error('Sessão encerrada. Faça login.');
   const body=await request('/auth/v1/token?grant_type=refresh_token',{method:'POST',auth:false,headers:{'Content-Type':'application/json'},body:JSON.stringify({refresh_token:session.refresh_token})});
   session={...body,expires_at:Math.floor(Date.now()/1000)+(body.expires_in||3600)};
   sessionStorage.setItem(sessionKey,JSON.stringify(session));
 }
 async function withAuth(fn){
   if(enabled && session?.expires_at && Date.now()/1000>session.expires_at-60)await refresh();
   return fn();
 }
 function signout(){session=null;sessionStorage.removeItem(sessionKey);}
 async function saveProduct(input){
   const p=normProduct(input);
   if(!p.name.trim())throw Error('Informe o nome do produto.');
   if(p.price != null && (!Number.isFinite(p.price)||p.price<0))throw Error('Preço inválido.');
   if(!enabled){
     if(!Number.isInteger(p.id)||p.id<=0)p.id=Math.max(0,...products.map(x=>x.id))+1;
     const index=products.findIndex(x=>x.id===p.id);
     if(index>=0)products[index]=p;else products.unshift(p);
     writeLocal(productKey,products);emit();return p;
   }
   return withAuth(async()=>{
     const isEdit=p.id>0;
     const data=toDb(p);
     const path=isEdit?'/rest/v1/catalog_products?id=eq.'+p.id:'/rest/v1/catalog_products';
     const r=await request(path,{method:isEdit?'PATCH':'POST',headers:{'Content-Type':'application/json','Prefer':'return=representation'},body:JSON.stringify(data)});
     if(!Array.isArray(r)||!r.length)throw Error('Nenhum registro alterado. Verifique suas permissões.');
     const result=fromDb(r[0]);const i=products.findIndex(x=>x.id===result.id);
     if(i>=0)products[i]=result;else products.unshift(result);
     emit();return result;
   });
 }
 async function saveSettings(input){
   const next={...settings,whatsapp:String(input.whatsapp||'').replace(/\D/g,''),empresa:String(input.empresa||'').trim(),cidade:String(input.cidade||'').trim(),tagline:String(input.tagline||'').trim(),subtitle:String(input.subtitle||'').trim()};
   if(!/^55\d{10,11}$/.test(next.whatsapp))throw Error('Informe WhatsApp no formato 55 + DDD + número.');
   if(!enabled){settings=next;writeLocal(settingsKey,settings);emit();return settings;}
   return withAuth(async()=>{
     await request('/rest/v1/site_settings?id=eq.1',{method:'PATCH',headers:{'Content-Type':'application/json','Prefer':'return=representation'},body:JSON.stringify({whatsapp:next.whatsapp,empresa:next.empresa,cidade:next.cidade,tagline:next.tagline,subtitle:next.subtitle})});
     settings=next;emit();return settings;
   });
 }
 async function saveSalesperson(input){
   const item=normSeller(input);
   if(item.name.length<2||item.name.length>100)throw Error('Informe o nome do vendedor (2 a 100 caracteres).');
   if(!/^55\d{10,11}$/.test(item.whatsapp))throw Error('WhatsApp do vendedor deve ter 55 + DDD + número.');
   if(!enabled){
     if(!item.id)item.id=Math.max(0,...sellers.map(x=>x.id))+1;
     const idx=sellers.findIndex(x=>x.id===item.id);if(idx>=0)sellers[idx]=item;else sellers.push(item);
     writeLocal(sellersKey,sellers);emit();return item;
   }
   return withAuth(async()=>{
     const data={name:item.name,whatsapp:item.whatsapp,active:item.active};
     const updated=await request('/rest/v1/sales_reps'+(item.id?'?id=eq.'+item.id:''),{method:item.id?'PATCH':'POST',headers:{'Content-Type':'application/json','Prefer':'return=representation'},body:JSON.stringify(data)});
     if(!updated?.length)throw Error('Não foi possível salvar o vendedor. Rode o SQL da V4 e confira as permissões.');
     const saved=normSeller(updated[0]);const idx=sellers.findIndex(x=>x.id===saved.id);if(idx>=0)sellers[idx]=saved;else sellers.push(saved);
     emit();return saved;
   });
 }
 async function saveRoutingRule(input){
   const rule=normRule(input);
   if(!sellers.some(s=>s.id===rule.sales_rep_id))throw Error('Escolha um vendedor cadastrado.');
   if(!rule.neighborhood&&!rule.segment&&!rule.city)throw Error('Informe ao menos bairro, cidade ou tipo de estabelecimento.');
   if(rule.priority<0||rule.priority>999||!Number.isInteger(rule.priority))throw Error('Prioridade deve ser entre 0 e 999.');
   if(!enabled){
     if(!rule.id)rule.id=Math.max(0,...routes.map(x=>x.id))+1;
     const idx=routes.findIndex(x=>x.id===rule.id);if(idx>=0)routes[idx]=rule;else routes.push(rule);
     writeLocal(routesKey,routes);emit();return rule;
   }
   return withAuth(async()=>{
     const data={sales_rep_id:rule.sales_rep_id,city:rule.city,neighborhood:rule.neighborhood,segment:rule.segment,priority:rule.priority,active:rule.active};
     const updated=await request('/rest/v1/routing_rules'+(rule.id?'?id=eq.'+rule.id:''),{method:rule.id?'PATCH':'POST',headers:{'Content-Type':'application/json','Prefer':'return=representation'},body:JSON.stringify(data)});
     if(!updated?.length)throw Error('Não foi possível salvar a regra. Execute a migração da V4.');
     const saved=normRule(updated[0]);const idx=routes.findIndex(x=>x.id===saved.id);if(idx>=0)routes[idx]=saved;else routes.push(saved);
     emit();return saved;
   });
 }
 async function deleteRoutingRule(id){
   id=Number(id);if(!Number.isInteger(id)||id<=0)throw Error('Regra inválida.');
   if(!enabled){routes=routes.filter(r=>r.id!==id);writeLocal(routesKey,routes);emit();return;}
   return withAuth(async()=>{
     await request('/rest/v1/routing_rules?id=eq.'+id,{method:'DELETE'});
     routes=routes.filter(r=>r.id!==id);emit();
   });
 }
 async function uploadPhoto(file){
   if(!file?.type?.match(/^image\/(png|jpeg|webp)$/))throw Error('Use PNG, JPG ou WebP.');
   if(file.size>3*1024*1024)throw Error('Imagem acima de 3 MB.');
   if(!enabled){return await new Promise((resolve,reject)=>{
     const r=new FileReader();r.onerror=()=>reject(Error('Erro ao ler foto'));
     r.onload=()=>{const img=new Image();img.onerror=()=>reject(Error('Imagem inválida'));
       img.onload=()=>{const scale=Math.min(1,820/Math.max(img.width,img.height));
         const c=document.createElement('canvas');c.width=Math.max(1,Math.round(img.width*scale));c.height=Math.max(1,Math.round(img.height*scale));
         c.getContext('2d').drawImage(img,0,0,c.width,c.height);resolve(c.toDataURL('image/webp',.76));};
       img.src=r.result;};r.readAsDataURL(file);
   });}
   return withAuth(async()=>{
     const ext=file.type==='image/jpeg'?'jpg':file.type.split('/')[1];
     const filename='foto-'+Date.now()+'-'+Math.random().toString(36).slice(2,10)+'.'+ext;
     await request('/storage/v1/object/product-images/'+filename,{method:'POST',headers:{'Content-Type':file.type,'x-upsert':'false'},body:file});
     return base+'/storage/v1/object/public/product-images/'+filename;
   });
 }
 async function seedCatalog(){
   if(!enabled)throw Error('O catálogo já está disponível no modo demonstração.');
   return withAuth(async()=>{
     const chunks=[];
     for(let i=0;i<initial.length;i+=50)chunks.push(initial.slice(i,i+50).map(x=>({id:x.id,...toDb(normProduct({...x,active:true,price:null}))})));
     for(const chunk of chunks){await request('/rest/v1/catalog_products?on_conflict=id',{method:'POST',headers:{'Content-Type':'application/json','Prefer':'resolution=ignore-duplicates,return=minimal'},body:JSON.stringify(chunk)});}
     await loadAdmin();return initial.length;
   });
 }
 function resetDemo(){[productKey,settingsKey,sellersKey,routesKey].forEach(x=>localStorage.removeItem(x));useLocal();}
 window.PF_BACKEND = {enabled,loadPublic,loadAdmin,getProducts,getSettings,signin,restore,signout,saveProduct,saveSettings,saveSalesperson,saveRoutingRule,deleteRoutingRule,getSalespeople,getRoutingRules,uploadPhoto,seedCatalog,resetDemo,originalCount:initial.length};
 if(!enabled)useLocal();
 window.addEventListener('storage',e=>{if(!enabled&&[productKey,settingsKey,sellersKey,routesKey].includes(e.key))useLocal();});
})();
